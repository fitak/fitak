-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2016 at 07:09 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fitak-dev`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE IF NOT EXISTS `data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb_id` bigint(20) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `group_id` bigint(20) DEFAULT NULL,
  `message` text COLLATE utf8mb4_czech_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `updated_time` datetime DEFAULT NULL,
  `comments` int(11) DEFAULT NULL,
  `type` enum('link','status','photo','video','offer','event') COLLATE utf8mb4_czech_ci NOT NULL DEFAULT 'status',
  `link` text COLLATE utf8mb4_czech_ci,
  `name` text COLLATE utf8mb4_czech_ci,
  `caption` text COLLATE utf8mb4_czech_ci,
  `description` text COLLATE utf8mb4_czech_ci,
  `picture` text COLLATE utf8mb4_czech_ci,
  `source` text COLLATE utf8mb4_czech_ci,
  `user` int(255) NOT NULL,
  `is_type_qa` bit(1) NOT NULL DEFAULT b'0',
  `deleted` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fb_id` (`fb_id`),
  KEY `parent_id` (`parent_id`),
  KEY `data_ibfk_2` (`group_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci AUTO_INCREMENT=135 ;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `fb_id`, `parent_id`, `group_id`, `message`, `created_time`, `updated_time`, `comments`, `type`, `link`, `name`, `caption`, `description`, `picture`, `source`, `user`, `is_type_qa`, `deleted`) VALUES
(98, 506717672871821, NULL, 445325479011041, '[zma][F] Zdravím, touhle dobou vím, že se nestíhám doučit vše co je potřeba na řádný termín. Když se teď zaměřím na MLO, měl bych na to více času a pravděpodobně ho mohl i udělat. Tím bych měl asi všechny předměty kromě ZMA, a svůj skutečný pokus o ZMA nechám až na opravný termín. Chci se zeptat, co by to znamenalo teď neudělat ZMA? Nebudu pak moct dělat jiný předmět který ze zma vychází? Opakuje se až zase v zimě? Stojí mi za to použít 1 z 6 extra pokusů? díky', '2016-06-04 06:47:20', '2016-06-04 16:10:37', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(99, 506717862871802, 98, 445325479011041, 'Teď tě asi úplně nechápu. Máš na mysli opravný termín zkoušky nebo vyloženě opakovat předmět? Po řádném termínu máš nárok na jeden opravný, jestli ti stojí za to použít jeden ze šesti druhých opravných pokusů je čistě na tvém uvážení. ZMA se vyučuje jen v zimním semestru, jestli je podmínkou pro nějaký předmět pochybuji, ale pan Tomáš Kalvoda určitě bude vědět lépe.', '2016-06-04 08:48:36', '2016-06-04 16:10:37', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(100, 506718022871786, 98, 445325479011041, 'Řekl bych, že podmínkou moc neni, ale v dalších matematických předmětech se asi můžou věci ze ZMA zase vyskytovat grin emoticon ... Jinak čistě z toho co jsem slyšel, tak se ten extra pokus na ZMA docela vyplatí, protože těch předmětů, který maj tak nízkou průchodnost za celý studium zas tolik neni...', '2016-06-03 16:49:07', '2016-06-03 16:49:07', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(101, 506718099538445, 99, 445325479011041, 'Ano, opravný termín zkoušky. Řádný je teď ve čtvrtek a to určitě nestíhám.', '2016-06-03 16:49:24', '2016-06-03 16:49:24', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'1'),
(102, 506718132871775, 99, 445325479011041, 'Pokud jdeš teprve na řádný termín, tak bych asi doporučovala tam dojít a zkusit to. Ať vidíš, kde máš největší mezery. Opravné termíny vidím vypsané na 3. 2., 10. 2. a 18. 2. takže pokud neuděláš řádný termín, máš dost času se to doučit na jeden z opravných. Pokud neuděláš ani ten opravný, pak se teprve budeš muset rozhodovat, jestli použít druhý opravný pokus.', '2016-06-04 00:49:41', '2016-06-04 00:49:41', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'1'),
(103, NULL, NULL, NULL, '[FI-FIL] Věděl by někdo jaké jsou podmínky absolvování předmětu FI-FIL pro nás fiťáky? Na Eduxu je, že se vše řídí podle stránek katedry, nicméně tam se evidentně počítá s variantou předmětu za 4 kredity a s cvičeními (my to máme za 2 kredity a bez cvičení). A případně doplňující otázka - mám ještě šanci ten předmět dát, když jsem tam dosud nebyl? Díky.', '2016-06-02 10:50:10', '2016-06-04 16:22:23', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(104, NULL, 103, NULL, 'Tak dle e-mailu od Zamarovského: zkouškové termíny budou v KOSu učit se na zkoušku z: Zamarovský, "Příběh antické filosofie", hlavně část po Aristotela včetně. žádné podmínky na vypracování čehokoliv během semestru nejsou', '2016-06-03 16:50:52', '2016-06-03 16:50:52', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(105, NULL, 103, NULL, 'Jestli ti můžu dát radu, neber tenhle předmět moc vážně. Já jsem přednášejícího viděl u zkoušky po prvé v životě, na prvním pokusu měl špatnou náladu, tak mě vyrazil. Po druhé už měl náladu dobrou, tak mi dal B za prakticky stejné znalosti. Na FELu bohužel takoví lidé pořád učí, i když podle mého názoru nemají na ČVUT co dělat. Na FITu jsem se naštěstí s ničím podobným nesetkal. Pokud nebude mít Zamarovsky vyloženě špatnou náladu, tak by mělo stačit naučit se jedno libovolné téma. U zkoušky se totiž většinou ptá, co umíš nejlíp a to chce pak slyšet.', '2016-06-03 20:51:11', '2016-06-03 16:51:37', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(106, NULL, 105, NULL, 'Díky, takže tomu rozumím správně, že během semestru žádná práce (semestrálka) vyžadována není a termín zkoušky bude normálně v KOSu?', '2016-06-03 16:51:25', '2016-06-03 16:51:25', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(107, NULL, 105, NULL, 'Spíš mu napiš, že vypíše zkoušku v KOSu není úplně stoprocentní, pokud si dobře pamatuju. Nebo jak píše kolega, můžeš vychytat ten test na přednášce, pokud tam budeš chodit :)', '2016-06-03 16:51:37', '2016-06-03 16:51:37', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(118, 507082276168694, NULL, 445325479011041, 'Ou jééé..Tak jak?', '2016-06-04 21:37:56', '2016-06-04 21:37:56', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'1'),
(119, NULL, NULL, NULL, 'Já si nemyslím, že je to úplně jako nejlepší...', '2016-06-04 21:08:27', '2016-06-04 15:26:34', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(120, NULL, 119, NULL, 'sdfg', '2016-06-04 15:17:36', '2016-06-04 15:17:36', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(121, NULL, 119, NULL, 'taky ne', '2016-06-04 15:18:51', '2016-06-04 15:18:51', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(122, NULL, 119, NULL, 'No, tak jako já asi jo no..', '2016-06-04 17:26:34', '2016-06-04 17:26:34', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'1'),
(123, 507110879499167, 98, 445325479011041, 'No, a co, bude to fachat? :)', '2016-06-04 15:27:48', '2016-06-04 15:27:48', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(124, 507112002832388, 99, 445325479011041, 'Já ho teda úplně chápu :)', '2016-06-04 15:34:11', '2016-06-04 15:34:11', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(125, 507121312831457, 99, 445325479011041, 'No, a co jako? :)', '2016-06-04 16:10:37', '2016-06-04 16:10:37', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(126, NULL, 103, NULL, 'Jo jo, to je vždycky velká paráda..', '2016-06-04 18:16:19', '2016-06-04 18:16:19', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'1'),
(127, NULL, 103, NULL, 'tak nevím nevím...', '2016-06-04 20:20:46', '2016-06-04 16:22:23', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(128, NULL, 103, NULL, 'No, já taky nevím..', '2016-06-04 16:21:38', '2016-06-04 16:21:38', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(129, NULL, 127, NULL, 'já jo, ale nepovím :P', '2016-06-04 16:22:06', '2016-06-04 16:22:06', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(130, NULL, 127, NULL, 'Ty jsi teda šupák :P', '2016-06-04 16:22:23', '2016-06-04 16:22:23', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'1', b'0'),
(131, 507148206162101, NULL, 445325479011041, '[fi-fil] No, tak jak teda? :)', '2016-06-04 16:52:58', '2016-06-04 16:52:58', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(132, 507148532828735, NULL, 445325479011041, '[fi-fil] je3te jsdfk', '2016-06-04 16:54:12', '2016-06-04 16:54:12', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0'),
(133, 507148616162060, NULL, 445325479011041, '[fi-fil] sdf sa', '2016-06-04 16:54:44', '2016-06-04 16:54:44', NULL, 'status', NULL, NULL, NULL, NULL, NULL, NULL, 4, b'0', b'0');

-- --------------------------------------------------------

--
-- Table structure for table `data_tags`
--

DROP TABLE IF EXISTS `data_tags`;
CREATE TABLE IF NOT EXISTS `data_tags` (
  `data_id` int(11) NOT NULL,
  `tags_id` int(11) NOT NULL,
  PRIMARY KEY (`data_id`,`tags_id`),
  KEY `data_id` (`data_id`),
  KEY `tags_id` (`tags_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

--
-- Dumping data for table `data_tags`
--

INSERT INTO `data_tags` (`data_id`, `tags_id`) VALUES
(98, 3),
(98, 4),
(103, 5),
(131, 5),
(132, 5),
(133, 5);

--
-- Triggers `data_tags`
--
DROP TRIGGER IF EXISTS `data_tags_ad`;
DELIMITER //
CREATE TRIGGER `data_tags_ad` AFTER DELETE ON `data_tags`
 FOR EACH ROW UPDATE `tags`
	SET `count` = `count` - 1
	WHERE `id` = OLD.`tags_id`
//
DELIMITER ;
DROP TRIGGER IF EXISTS `data_tags_ai`;
DELIMITER //
CREATE TRIGGER `data_tags_ai` AFTER INSERT ON `data_tags`
 FOR EACH ROW UPDATE `tags`
	SET `count` = `count` + 1
	WHERE `id` = NEW.`tags_id`
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` bigint(20) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_czech_ci NOT NULL,
  `closed` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `closed`) VALUES
(445325479011041, 'Fiťák test', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ip`
--

DROP TABLE IF EXISTS `ip`;
CREATE TABLE IF NOT EXISTS `ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(150) COLLATE utf8mb4_czech_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `ip`
--

INSERT INTO `ip` (`id`, `ip`) VALUES
(1, '::1'),
(2, '155.92.111.71'),
(3, '155.92.110.79'),
(4, '155.92.64.78'),
(5, '155.92.111.196'),
(6, '75.37.158.65'),
(7, '216.169.138.58'),
(8, '62.245.79.68'),
(9, '194.213.62.154');

-- --------------------------------------------------------

--
-- Table structure for table `key_value`
--

DROP TABLE IF EXISTS `key_value`;
CREATE TABLE IF NOT EXISTS `key_value` (
  `key` varchar(190) COLLATE utf8mb4_czech_ci NOT NULL,
  `value` text COLLATE utf8mb4_czech_ci NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

--
-- Dumping data for table `key_value`
--

INSERT INTO `key_value` (`key`, `value`) VALUES
('crawler.since.445325479011041', '1453311642'),
('facebook.access_token', '"CAAFOFmseozIBANKF20eRPfOZABGymeMG5wZBXn8V27k2GJu6Soe4F4L3sNCItKnqSZCuG6Uk7FOWLvBIOJaNSZAK0nlRSdNDP5BXTa53aVIqVlu3YwlzxgvrCgLzegZC0W21QeWlTtbyHMM2RnjjEuOPB6qrFrjIVZB23Vc4vh8fLbEB735o9tEhbJePRXywcZD"'),
('facebook.access_token_expires', '1454864256');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(100) COLLATE utf8mb4_czech_ci NOT NULL,
  `file` varchar(100) COLLATE utf8mb4_czech_ci NOT NULL,
  `checksum` char(32) COLLATE utf8mb4_czech_ci NOT NULL,
  `executed` datetime NOT NULL,
  `ready` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `type_file` (`group`,`file`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci AUTO_INCREMENT=35 ;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `group`, `file`, `checksum`, `executed`, `ready`) VALUES
(1, 'structures', '2014-10-03-001-init.sql', 'ebfd3446fe477fbe180c55c3524c0922', '2016-01-20 18:34:56', 1),
(2, 'structures', '2014-10-03-002-innodb.sql', 'e22a942be549860a6ef8062b7bf4a760', '2016-01-20 18:34:56', 1),
(3, 'structures', '2014-10-03-003-groups-pk.sql', '8b9c001ede91bc2b5c7b82b6c0cb5847', '2016-01-20 18:34:57', 1),
(4, 'structures', '2014-10-03-004-foreign-keys.sql', 'f25d707360d31b24c1cde59612b04d3a', '2016-01-20 18:34:57', 1),
(5, 'basic-data', '2014-10-03-005-groups.sql', '32a6f3208d4a13be77dcbefa9b2a8e95', '2016-01-20 18:34:57', 1),
(6, 'basic-data', '2014-10-03-006-ip.sql', '0c47e1c9361dfbcf9cc8660a7940745a', '2016-01-20 18:34:57', 1),
(7, 'structures', '2014-10-03-009-news-created-index.sql', '1301ff96a89426d7c4b5b26046d58e1d', '2016-01-20 18:34:57', 1),
(8, 'structures', '2014-10-05-001-users.sql', '8a0036dd264565c7a420f7f0c8077dbd', '2016-01-20 18:34:57', 1),
(9, 'structures', '2014-10-05-004-tags-unique-name.sql', '7a6425b76a974ba83cf3e31558ec0566', '2016-01-20 18:34:57', 1),
(10, 'structures', '2014-10-05-005-tags-count-trigger.sql', '604b9409f38a27340361087b82f5073d', '2016-01-20 18:34:57', 1),
(11, 'structures', '2014-10-06-001-drop-tokens.sql', 'aa2ee2944449a5709fbe0e1370fb19b2', '2016-01-20 18:34:57', 1),
(12, 'structures', '2014-10-06-002-keyvalue.sql', '10b0bc0fdb0ed0fc4e0a3e459ec7ccc3', '2016-01-20 18:34:58', 1),
(13, 'structures', '2014-10-06-003-text-fields.sql', 'e372f0385e73e8bc4b57dd1ed49b6451', '2016-01-20 18:34:58', 1),
(14, 'structures', '2014-10-07-001-revert-name-text-fields.sql', '70efddf286f007419a49857687e7089e', '2016-01-20 18:34:58', 1),
(15, 'structures', '2014-10-07-002-drop-likes.sql', '6feeceb1c1ed5405674f7f8bb95cabe6', '2016-01-20 18:34:58', 1),
(16, 'structures', '2014-10-08-001-remove-like-count.sql', 'f61cce91a9874b434a68b6f271ef46cf', '2016-01-20 18:34:58', 1),
(17, 'structures', '2014-10-09-001-users-password-reset-token.sql', '1deaadb3c99fad67eefb3fa3295c8c7f', '2016-01-20 18:34:58', 1),
(18, 'structures', '2014-10-13-001-tags-favorite.sql', 'fa02d0bac5e94c6667422a77abf27381', '2016-01-20 18:34:58', 1),
(19, 'structures', '2015-04-28-001-users-facebook.sql', 'bba72a543dbab4111b0ef85270ed474a', '2016-01-20 18:34:58', 1),
(20, 'structures', '2015-05-19-001-update-data-type.sql', 'a180c13fe391d0f41ad0bb084aa8a707', '2016-01-20 18:34:58', 1),
(21, 'structures', '2015-12-07-001-utf8-to-utf8md4.sql', 'ef14532213247baf8900ffe7005045c7', '2016-01-20 18:34:59', 1),
(22, 'structures', '2015-12-07-002-inherit-charset-and-collation.sql', '2c2940fb2cd85a914e760a5f7fe89bf4', '2016-01-20 18:34:59', 1),
(23, 'structures', '2015-12-09-001-truncate-all-data.sql', '1ccdd6dc7f124c330d0b8605efa5ab77', '2016-01-20 18:34:59', 1),
(24, 'structures', '2015-12-09-002-change-data-primary-key.sql', '0c203df5e99cb6680b6b4f7f018bf1a7', '2016-01-20 18:34:59', 1),
(25, 'basic-data', '2015-12-10-001-[dev]-delete-other-groups.sql', '325348a7d2db79e09d73e0af16a6d258', '2016-01-20 18:35:00', 1),
(26, 'structures', '2015-12-10-001-remove-id-in-data_tags.sql', '12c792ab875b8af72ed8e3f6a74d2444', '2016-01-20 18:35:00', 1),
(27, 'basic-data', '2015-12-10-002-[dev]-add-access-token.sql', '325348a7d2db79e09d73e0af16a6d258', '2016-01-20 18:35:00', 1),
(28, 'basic-data', '2015-12-10-003-[dev]-add-fb-token.sql', '5f52501c03bac9fd34531113c27b3726', '2016-01-20 18:35:00', 1),
(29, 'structures', '2015-12-12-001-move-and-extend-user.sql', 'f0242b6ed9e8e4eb3e2cbbdebf4c2200', '2016-01-20 18:35:00', 1),
(30, 'basic-data', '2015-12-12-002-[dev]-user-hermamat.sql', '4e6e92a11bbafbcd308c1ec62be310d1', '2016-01-20 18:35:00', 1),
(31, 'structures', '2015-12-14-001-set-group-id-optional.sql', 'bcb240c06fe3e2f8cb680eaf1279e644', '2016-01-20 18:35:00', 1),
(32, 'basic-data', '2015-12-28-001-[dev]-use-only-test-group.sql', 'bf53f33d5378ebcc5c7c4e1d1ed46e7e', '2016-01-20 18:35:00', 1),
(33, 'structures', '2016-01-16-001-add-votes-table.sql', 'ce64afa143b56375ff40ddc99aed3daa', '2016-01-20 18:35:00', 1),
(34, 'structures', '2016-01-20-001-add-qa-type-to-data-table.sql', '67e2d79ea58b635082101243f568adba', '2016-01-20 18:35:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8mb4_czech_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `saved_searches`
--

DROP TABLE IF EXISTS `saved_searches`;
CREATE TABLE IF NOT EXISTS `saved_searches` (
  `id` int(10) unsigned NOT NULL,
  `query` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(190) COLLATE utf8mb4_czech_ci NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `count`) VALUES
(3, 'zma', 1),
(4, 'f', 1),
(5, 'fi-fil', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tags_favorite`
--

DROP TABLE IF EXISTS `tags_favorite`;
CREATE TABLE IF NOT EXISTS `tags_favorite` (
  `user_id` int(10) unsigned NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`tag_id`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `password_hash` char(60) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `sign_up_token_hash` char(60) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `sign_up_time` datetime DEFAULT NULL,
  `password_reset_token_hash` char(60) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `fb_id` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `fb_access_token` text COLLATE utf8mb4_czech_ci,
  `name` varchar(100) COLLATE utf8mb4_czech_ci NOT NULL,
  `profile_picture` varchar(255) COLLATE utf8mb4_czech_ci DEFAULT NULL,
  `registered` tinyint(1) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password_hash`, `sign_up_token_hash`, `sign_up_time`, `password_reset_token_hash`, `fb_id`, `fb_access_token`, `name`, `profile_picture`, `registered`, `admin`) VALUES
(4, 'hermamat@fit.cvut.cz', '$2y$10$gHzFSIPWk70oROOYvqXuTewemf0WRmrnQD8.UW/7AetgeGRQ8.Hui', NULL, '2016-06-03 18:46:43', NULL, '10206167320206404', 'EAAFOFmseozIBAMkfn0QG41moZCtCCrKm9biupAzY7eLsp1gXFPUrbsJLAZB5FXxyZC9ZCXx4vfeaqwvu7hmpmoV0IexR7apXibvq2l6vaYz8mH9iVjKYbdZA2zK3otQHTa4DSxpOHZBew0SyZAYfieo', 'Matěj Heřman', 'https://scontent.xx.fbcdn.net/v/t1.0-1/c74.85.466.466/s50x50/314778_2380960567852_726026646_n.jpg?oh=fa09bd4fdd6903db8e80d7daa228aa5f&oe=580CBD37', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_x_saved_searches`
--

DROP TABLE IF EXISTS `users_x_saved_searches`;
CREATE TABLE IF NOT EXISTS `users_x_saved_searches` (
  `user_id` int(10) unsigned NOT NULL,
  `saved_search_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`saved_search_id`),
  KEY `users_x_saved_searches_2` (`saved_search_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_czech_ci;

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

DROP TABLE IF EXISTS `votes`;
CREATE TABLE IF NOT EXISTS `votes` (
  `data_id` int(11) NOT NULL,
  `is_downvote` bit(1) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`data_id`,`user_id`),
  KEY `votes_ibfk_2` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`data_id`, `is_downvote`, `user_id`) VALUES
(99, b'0', 4),
(100, b'0', 4),
(103, b'0', 4),
(105, b'1', 4),
(128, b'0', 4);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `data`
--
ALTER TABLE `data`
  ADD CONSTRAINT `data_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `data` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `data_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`);

--
-- Constraints for table `data_tags`
--
ALTER TABLE `data_tags`
  ADD CONSTRAINT `data_tags_ibfk_1` FOREIGN KEY (`data_id`) REFERENCES `data` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `data_tags_ibfk_2` FOREIGN KEY (`tags_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tags_favorite`
--
ALTER TABLE `tags_favorite`
  ADD CONSTRAINT `tags_favorite_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tags_favorite_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`);

--
-- Constraints for table `users_x_saved_searches`
--
ALTER TABLE `users_x_saved_searches`
  ADD CONSTRAINT `users_x_saved_searches_2` FOREIGN KEY (`saved_search_id`) REFERENCES `saved_searches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_x_saved_searches_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `votes`
--
ALTER TABLE `votes`
  ADD CONSTRAINT `votes_ibfk_1` FOREIGN KEY (`data_id`) REFERENCES `data` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `votes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
